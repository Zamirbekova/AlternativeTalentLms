package com.hadicha.dao;

import com.hadicha.entity.Company;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

public class CompanyDaoImpl implements CompanyDao{
    @PersistenceContext
   private EntityManager entityManager;

    @Override
    public void save(Company company) {
        entityManager.persist(company);
        System.out.println("save");
    }
}
