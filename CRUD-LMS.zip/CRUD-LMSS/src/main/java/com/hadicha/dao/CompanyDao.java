package com.hadicha.dao;

import com.hadicha.entity.Company;

public interface CompanyDao {
    void save(Company company);

}
