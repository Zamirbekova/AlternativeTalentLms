package com.hadicha.enums;

public enum Study_Format {
    ONLAIN,
    OFFLAIN
}
