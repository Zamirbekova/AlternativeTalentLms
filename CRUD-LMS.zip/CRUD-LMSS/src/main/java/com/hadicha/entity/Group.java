package com.hadicha.entity;

import javax.persistence.*;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "groups")
public class Group {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String groupName;
    private Date dateOfStart;
    private Date dateOfFinish;

    @ManyToMany(mappedBy = "group",cascade = {CascadeType.MERGE,CascadeType.PERSIST,CascadeType.REFRESH,CascadeType.DETACH})
    List<Course>course;
    @OneToMany(cascade = CascadeType.ALL)
    List<Student> student;
}
